#!/bin/bash

python2 -m SimpleHTTPServer 8001